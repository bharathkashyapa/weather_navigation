from flask import Flask,request
from datetime import datetime
import flask
import json
import weatherjson
app = Flask(__name__)

@app.route('/')
def index():
	return flask.render_template('index3.html')

@app.route('/search/', methods=['POST'])
def search():
    date=request.form['date']
    time=request.form['time']
    datelist=date.split('/')
    date_in=datelist[2]+"-"+datelist[0]+"-"+datelist[1]
    epoch_in = datetime.strptime(date+" "+time,"%m/%d/%Y %H:%M").strftime('%s')
    print date_in,epoch_in
    #return "pind"
    return json.dumps(weatherjson.get_apixu_weather(date_in,epoch_in))
@app.route('/getcurrentweather/',methods=['GET'])
def getcurrentweather():
	return json.dumps(weatherjson.getcurrentweather())

@app.route('/getforecast',methods=['GET'])
def getforecast():
	date=request.args['date']
	time=request.args['time']
	print date,time
	zipcode=['2745','2747','2766','2145','2150','2142','2150','2127']
	epoch_in_apixu=str(int(datetime.strptime(date+" "+time,"%m/%d/%Y %H:%M").strftime('%s'))-14400)
	epoch_in_owm = str(int(datetime.strptime(date+" "+time,"%m/%d/%Y %H:%M").strftime('%s'))+15200) #timezone
	#print epoch_in
	datelist=date.split('/')
	date_in=datelist[2]+"-"+datelist[0]+"-"+datelist[1]
	apixu_weather=weatherjson.get_apixu_weather(date_in,epoch_in_apixu)
	print apixu_weather
	visibility=apixu_weather["vis_km"]
	dewpoint=apixu_weather["dewpoint_c"]
	forecast_dict=dict()
	for i in zipcode:
		temp_forecast=weatherjson.get_owm_weather(i,epoch_in_owm)
		'''if temp_forecast["rain"]=="":
			temp_rain='0'
		else:
			temp_rain='5'''
		temp_rain="8"
		print temp_forecast,"\n"
		forecast_i=dict()
		forecast_i["rain"]=temp_rain
		forecast_i["dew"]=dewpoint
		forecast_i["visibility"]=visibility
		forecast_i["icon"]=temp_forecast["weather"][0]["icon"]
		forecast_i["description"]=temp_forecast["weather"][0]["description"]
		forecast_i["temperature"]=str(float(temp_forecast["main"]["temp"])-273.15)
		forecast_i["humidity"]=str(int(temp_forecast["main"]["humidity"])/float(100))
		forecast_dict[i]=forecast_i
	forecast_dict["ETA"]="24"
	return json.dumps(forecast_dict)







#if __name__=='__main__':
#	app.run(debug=True)
#https://oss.adm.ntu.edu.sg/sngy0011/wp-content/uploads/sites/540/2017/02/raining-zoetrope.gif
#http://ampbukaka.com/wp-content/uploads/2015/05/street-only2.jpg
#http://www.andreashellqvist.se/wp-content/uploads/2012/06/post.jpg
#http://colorfully.eu/wp-content/uploads/2012/06/weather-forecast-facebook-cover.jpg
#<script type=text/javascript src="{{url_for('static', filename='jquery.min.js') }}"></script>
#background-image: url('https://www.co-opinsurance.com/images/default-source/802-creative-images/icyroads1400.jpg?sfvrsn=4');