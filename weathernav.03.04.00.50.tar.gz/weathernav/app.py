from flask import Flask,request
from datetime import datetime
import flask
import json
import weatherjson
app = Flask(__name__)

@app.route('/')
def index():
	return flask.render_template('index2.html')
@app.route('/search/', methods=['POST'])
def search():
    date=request.form['date']
    time=request.form['time']
    datelist=date.split('/')
    date_in=datelist[2]+"-"+datelist[0]+"-"+datelist[1]
    epoch_in = datetime.strptime(date+" "+time,"%m/%d/%Y %H:%M").strftime('%s')
    print date_in,epoch_in
    #return "pind"
    return json.dumps(weatherjson.get_apixu_weather(date_in,epoch_in))
#if __name__=='__main__':
#	app.run(debug=True)
#https://oss.adm.ntu.edu.sg/sngy0011/wp-content/uploads/sites/540/2017/02/raining-zoetrope.gif
#http://ampbukaka.com/wp-content/uploads/2015/05/street-only2.jpg
#http://www.andreashellqvist.se/wp-content/uploads/2012/06/post.jpg
#http://colorfully.eu/wp-content/uploads/2012/06/weather-forecast-facebook-cover.jpg
#<script type=text/javascript src="{{url_for('static', filename='jquery.min.js') }}"></script>