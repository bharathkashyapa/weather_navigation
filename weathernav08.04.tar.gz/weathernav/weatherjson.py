import json,random,time
import urllib
import xml.etree.ElementTree as ET
open_weather_map_keys=["d1e9ad13204dd9560d965677d1e8e3f4","80eecdb42927b9fe4b1de1b3dafacd6a","4cd8a3d2d52e822eeb3f51fa44e7849a"]
dark_sky_keys=["b13c635c07fe4ad371da048f7771b9a4","c904831ee57c0a6095b58eb5a4029092","62abbf6babaabd900537fb44193f8333"]


def get_owm_weather(zipcode,epoch_in):
	x=urllib.urlopen("http://api.openweathermap.org/data/2.5/forecast?zip="+zipcode+",au&APPID="+random.choice(open_weather_map_keys)+"&mode=json")
	json_object=json.loads(x.read())
	#print json_object
	for i in json_object["list"]:
		if abs((int(i["dt"])-int(epoch_in)))<=5400:
			print i["dt"]
			forecast=i
			break
	return forecast

def get_apixu_weather(date,epoch_in):		#includes current weather and visibilty
	print "apixu called",date,epoch_in
	x = urllib.urlopen('http://api.apixu.com/v1/forecast.json?key=e887ae03519e494a98b181004173003&q=Sydney&days=5')
	json_object=json.loads(x.read())
	current_weather= json_object['current']
	hourly=json_object['forecast']
	for i in hourly["forecastday"]:
		if i["date"]==date:
			dateforecast=i
			break
	for i in dateforecast["hour"]:
		if abs(int(i["time_epoch"])-int(epoch_in))<=1800:
			hourlyforecast=i
			break
	return i
def getcurrentweather():
	x=urllib.urlopen("https://api.darksky.net/forecast/62abbf6babaabd900537fb44193f8333/-33.848408,-151.065059")
	json_object=json.loads(x.read())
	return json_object["currently"]
if __name__=='__main__':
	#apixu_object=get_apixu_weather("2017-04-03",1491141605)
	#print apixu_object
	zipcode=['2745','2747','2766','2145','2150','2142','2150','2127']
	for i in zipcode:
		print get_owm_weather(i,int(time.time())+45000)